import { useState, useRef, useCallback } from 'react';
import { Upload, X, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface UploadedFile {
  id: string;
  file: File;
  preview: string;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
  uploadedUrl?: string;
}

interface DragDropUploadProps {
  onFilesSelected: (files: UploadedFile[]) => Promise<void>;
  maxFiles?: number;
  maxFileSize?: number; // em bytes
  acceptedFormats?: string[];
  multiple?: boolean;
}

export default function DragDropUpload({
  onFilesSelected,
  maxFiles = 10,
  maxFileSize = 5 * 1024 * 1024, // 5MB padrão
  acceptedFormats = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'],
  multiple = true,
}: DragDropUploadProps) {
  const [uploadedFiles, setUploadedFiles] = useState<UploadedFile[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const validateFile = (file: File): string | null => {
    if (!acceptedFormats.includes(file.type)) {
      return `Formato não suportado: ${file.type}. Formatos aceitos: ${acceptedFormats.join(', ')}`;
    }

    if (file.size > maxFileSize) {
      return `Arquivo muito grande. Máximo: ${(maxFileSize / 1024 / 1024).toFixed(2)}MB`;
    }

    return null;
  };

  const processFiles = useCallback(
    (files: FileList | File[]) => {
      const fileArray = Array.from(files);
      const validFiles: UploadedFile[] = [];

      // Verificar limite de arquivos
      if (uploadedFiles.length + fileArray.length > maxFiles) {
        alert(`Máximo de ${maxFiles} arquivos permitidos`);
        return;
      }

      fileArray.forEach((file) => {
        const error = validateFile(file);

        if (error) {
          validFiles.push({
            id: Math.random().toString(36),
            file,
            preview: '',
            status: 'error',
            error,
          });
        } else {
          const reader = new FileReader();
          reader.onload = (e) => {
            setUploadedFiles((prev) =>
              prev.map((f) =>
                f.file === file && !f.preview
                  ? { ...f, preview: e.target?.result as string }
                  : f
              )
            );
          };
          reader.readAsDataURL(file);

          validFiles.push({
            id: Math.random().toString(36),
            file,
            preview: '',
            status: 'pending',
          });
        }
      });

      setUploadedFiles((prev) => [...prev, ...validFiles]);
    },
    [uploadedFiles.length, maxFiles, acceptedFormats, maxFileSize]
  );

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setIsDragging(false);

    const { files } = e.dataTransfer;
    processFiles(files);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { files } = e.target;
    if (files) {
      processFiles(files);
    }
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  const removeFile = (id: string) => {
    setUploadedFiles((prev) => prev.filter((f) => f.id !== id));
  };

  const handleUpload = async () => {
    const filesToUpload = uploadedFiles.filter((f) => f.status === 'pending' || f.status === 'error');

    if (filesToUpload.length === 0) {
      alert('Nenhum arquivo para enviar');
      return;
    }

    setIsUploading(true);

    try {
      // Atualizar status para uploading
      setUploadedFiles((prev) =>
        prev.map((f) =>
          filesToUpload.some((tu) => tu.id === f.id)
            ? { ...f, status: 'uploading' }
            : f
        )
      );

      // Chamar callback com arquivos
      await onFilesSelected(filesToUpload);

      // Atualizar status para success
      setUploadedFiles((prev) =>
        prev.map((f) =>
          filesToUpload.some((tu) => tu.id === f.id)
            ? { ...f, status: 'success' }
            : f
        )
      );

      // Limpar após 2 segundos
      setTimeout(() => {
        setUploadedFiles((prev) =>
          prev.filter((f) => !filesToUpload.some((tu) => tu.id === f.id))
        );
      }, 2000);
    } catch (error) {
      setUploadedFiles((prev) =>
        prev.map((f) =>
          filesToUpload.some((tu) => tu.id === f.id)
            ? {
                ...f,
                status: 'error',
                error: error instanceof Error ? error.message : 'Erro ao enviar arquivo',
              }
            : f
        )
      );
    } finally {
      setIsUploading(false);
    }
  };

  const clearAll = () => {
    setUploadedFiles([]);
  };

  return (
    <div className="w-full space-y-4">
      {/* Drag and Drop Area */}
      <div
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
        className={`relative border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-all ${
          isDragging
            ? 'border-blue-500 bg-blue-50'
            : 'border-gray-300 bg-gray-50 hover:border-gray-400'
        }`}
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple={multiple}
          onChange={handleFileInputChange}
          accept={acceptedFormats.join(',')}
          className="hidden"
        />

        <div className="flex flex-col items-center justify-center">
          <Upload className="w-12 h-12 text-gray-400 mb-3" />
          <p className="text-lg font-semibold text-gray-900 mb-1">
            Arraste imagens aqui ou clique para selecionar
          </p>
          <p className="text-sm text-gray-600">
            Formatos suportados: JPEG, PNG, WebP, GIF | Máximo: {(maxFileSize / 1024 / 1024).toFixed(2)}MB
          </p>
        </div>
      </div>

      {/* Uploaded Files Preview */}
      {uploadedFiles.length > 0 && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold text-gray-900">
              Arquivos selecionados ({uploadedFiles.length}/{maxFiles})
            </h3>
            {uploadedFiles.length > 0 && (
              <button
                onClick={clearAll}
                className="text-sm text-red-600 hover:text-red-700 font-medium"
              >
                Limpar tudo
              </button>
            )}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {uploadedFiles.map((file) => (
              <div
                key={file.id}
                className="relative group rounded-lg overflow-hidden bg-gray-100 aspect-square"
              >
                {/* Preview Image */}
                {file.preview && (
                  <img
                    src={file.preview}
                    alt={file.file.name}
                    className="w-full h-full object-cover"
                  />
                )}

                {/* Status Overlay */}
                <div
                  className={`absolute inset-0 flex items-center justify-center transition-opacity ${
                    file.status === 'pending' || file.status === 'error'
                      ? 'bg-black/0 group-hover:bg-black/40'
                      : file.status === 'uploading'
                      ? 'bg-black/40'
                      : 'bg-black/0'
                  }`}
                >
                  {file.status === 'uploading' && (
                    <div className="flex flex-col items-center gap-2">
                      <div className="animate-spin rounded-full h-6 w-6 border-2 border-white border-t-transparent" />
                      <span className="text-xs text-white font-medium">Enviando...</span>
                    </div>
                  )}

                  {file.status === 'success' && (
                    <CheckCircle className="w-8 h-8 text-green-400" />
                  )}

                  {file.status === 'error' && (
                    <AlertCircle className="w-8 h-8 text-red-400" />
                  )}
                </div>

                {/* Remove Button */}
                {(file.status === 'pending' || file.status === 'error') && (
                  <button
                    onClick={() => removeFile(file.id)}
                    className="absolute top-1 right-1 bg-red-500 hover:bg-red-600 text-white rounded-full p-1 opacity-0 group-hover:opacity-100 transition-opacity"
                  >
                    <X className="w-4 h-4" />
                  </button>
                )}

                {/* Error Message */}
                {file.status === 'error' && file.error && (
                  <div className="absolute bottom-0 left-0 right-0 bg-red-500 text-white text-xs p-1 text-center">
                    {file.error}
                  </div>
                )}

                {/* File Name */}
                <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-xs p-2 truncate">
                  {file.file.name}
                </div>
              </div>
            ))}
          </div>

          {/* Upload Button */}
          {uploadedFiles.some((f) => f.status === 'pending' || f.status === 'error') && (
            <div className="flex gap-3 justify-end">
              <Button
                variant="outline"
                onClick={clearAll}
                disabled={isUploading}
              >
                Cancelar
              </Button>
              <Button
                onClick={handleUpload}
                disabled={isUploading}
                className="bg-blue-600 hover:bg-blue-700"
              >
                {isUploading ? 'Enviando...' : 'Enviar Arquivos'}
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
