import { useState, useRef, useEffect } from 'react';
import { Edit2, Check, X } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface EditableTextProps {
  value: string;
  onSave: (newValue: string) => void;
  placeholder?: string;
  multiline?: boolean;
  maxLength?: number;
  className?: string;
  displayClassName?: string;
  editClassName?: string;
}

export default function EditableText({
  value,
  onSave,
  placeholder = 'Clique para editar',
  multiline = false,
  maxLength = 500,
  className = '',
  displayClassName = '',
  editClassName = '',
}: EditableTextProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editValue, setEditValue] = useState(value);
  const inputRef = useRef<HTMLInputElement | HTMLTextAreaElement>(null);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
      inputRef.current.select();
    }
  }, [isEditing]);

  const handleSave = () => {
    if (editValue.trim() !== '') {
      onSave(editValue.trim());
      setIsEditing(false);
    }
  };

  const handleCancel = () => {
    setEditValue(value);
    setIsEditing(false);
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !multiline) {
      handleSave();
    } else if (e.key === 'Escape') {
      handleCancel();
    }
  };

  if (isEditing) {
    return (
      <div className={`space-y-2 ${className}`}>
        {multiline ? (
          <textarea
            ref={inputRef as React.Ref<HTMLTextAreaElement>}
            value={editValue}
            onChange={(e) => setEditValue(e.target.value.slice(0, maxLength))}
            onKeyDown={handleKeyDown}
            maxLength={maxLength}
            className={`w-full px-3 py-2 border border-blue-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300 resize-none ${editClassName}`}
            rows={3}
            placeholder={placeholder}
          />
        ) : (
          <input
            ref={inputRef as React.Ref<HTMLInputElement>}
            type="text"
            value={editValue}
            onChange={(e) => setEditValue(e.target.value.slice(0, maxLength))}
            onKeyDown={handleKeyDown}
            maxLength={maxLength}
            className={`w-full px-3 py-2 border border-blue-500 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-300 ${editClassName}`}
            placeholder={placeholder}
          />
        )}

        {/* Character count */}
        <div className="flex items-center justify-between">
          <div className="text-xs text-gray-500">
            {editValue.length} / {maxLength}
          </div>

          {/* Action Buttons */}
          <div className="flex gap-2">
            <Button
              size="sm"
              variant="outline"
              onClick={handleCancel}
              className="text-gray-600 hover:text-gray-900"
            >
              <X className="w-4 h-4" />
            </Button>
            <Button
              size="sm"
              onClick={handleSave}
              className="bg-green-600 hover:bg-green-700 text-white"
            >
              <Check className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={() => setIsEditing(true)}
      className={`group flex items-start justify-between gap-2 p-2 rounded-lg hover:bg-gray-100 cursor-pointer transition-colors ${className}`}
    >
      <div className={`flex-1 ${displayClassName}`}>
        {value || <span className="text-gray-400 italic">{placeholder}</span>}
      </div>
      <Edit2 className="w-4 h-4 text-gray-400 group-hover:text-gray-600 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0 mt-0.5" />
    </div>
  );
}
