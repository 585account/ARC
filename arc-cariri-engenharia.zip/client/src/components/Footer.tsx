import { Facebook, Instagram, Linkedin, Mail, MapPin, Phone, MessageCircle } from 'lucide-react';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-primary text-white">
      <div className="container section-padding">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Company Info */}
          <div>
            <div className="mb-4">
              <img 
                src="https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/pasted_file_5fwkbf_image_6ce3ad34.png"
                alt="ARC Cariri Engenharia Logo"
                className="h-16 w-auto mb-3"
              />
            </div>
            <p className="text-blue-100 text-sm leading-relaxed">
              Construindo qualidade, segurança e confiança em cada projeto residencial.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-bold text-lg mb-4">Links Rápidos</h4>
            <ul className="space-y-2">
              <li><a href="#home" className="text-blue-100 hover:text-white transition-colors">Início</a></li>
              <li><a href="#about" className="text-blue-100 hover:text-white transition-colors">Sobre</a></li>
              <li><a href="#services" className="text-blue-100 hover:text-white transition-colors">Serviços</a></li>
              <li><a href="#portfolio" className="text-blue-100 hover:text-white transition-colors">Portfólio</a></li>
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-bold text-lg mb-4">Serviços</h4>
            <ul className="space-y-2">
              <li><a href="#services" className="text-blue-100 hover:text-white transition-colors">Construção de Casas</a></li>
              <li><a href="#services" className="text-blue-100 hover:text-white transition-colors">Gerenciamento de Obras</a></li>
              <li><a href="#services" className="text-blue-100 hover:text-white transition-colors">Reformas e Ampliações</a></li>
              <li><a href="#services" className="text-blue-100 hover:text-white transition-colors">Consultoria Técnica</a></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="font-bold text-lg mb-4">Contato</h4>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2">
                <MapPin size={18} className="mt-1 flex-shrink-0" />
                <span className="text-blue-100 text-sm">Crato – Ceará, Brasil</span>
              </li>
              <li className="flex items-center space-x-2">
                <Phone size={18} />
                <a href="https://wa.me/88988883633" target="_blank" rel="noopener noreferrer" className="text-blue-100 hover:text-white transition-colors">(88) 98888-3633</a>
              </li>
              <li className="flex items-center space-x-2">
                <Mail size={18} />
                <a href="mailto:contato@arccariri.com.br" className="text-blue-100 hover:text-white transition-colors text-sm">contato@arccariri.com.br</a>
              </li>
            </ul>
          </div>
        </div>

        {/* Social Links */}
        <div className="border-t border-blue-400 pt-8 flex flex-col md:flex-row items-center justify-between">
          <p className="text-blue-100 text-sm mb-4 md:mb-0">
            © {currentYear} ARC Cariri Engenharia. Todos os direitos reservados.
          </p>
          <div className="flex items-center space-x-4">
            <a href="https://wa.me/88988883633" target="_blank" rel="noopener noreferrer" className="text-blue-100 hover:text-white transition-colors" aria-label="WhatsApp">
              <MessageCircle size={20} />
            </a>
            <a href="https://www.instagram.com/arc.caririengenharia?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" target="_blank" rel="noopener noreferrer" className="text-blue-100 hover:text-white transition-colors" aria-label="Instagram">
              <Instagram size={20} />
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
