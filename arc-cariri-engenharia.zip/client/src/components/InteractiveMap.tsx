import { useEffect, useRef, useState } from 'react';
import { MapPin, X, Navigation } from 'lucide-react';

interface Work {
  id: string;
  name: string;
  type: string;
  status: 'completed' | 'ongoing' | 'planned';
  latitude: number;
  longitude: number;
  startDate: string;
  endDate: string;
  description: string;
  images: string[];
  address: string;
}

interface InteractiveMapProps {
  works: Work[];
  onMarkerClick?: (work: Work) => void;
  initialCenter?: { lat: number; lng: number };
  initialZoom?: number;
}

const statusColors = {
  completed: '#22c55e', // Verde
  ongoing: '#eab308', // Amarelo
  planned: '#ef4444', // Vermelho
};

const statusLabels = {
  completed: 'Concluída',
  ongoing: 'Em Andamento',
  planned: 'Planejada',
};

export default function InteractiveMap({
  works,
  onMarkerClick,
  initialCenter = { lat: -7.1219, lng: -34.8413 }, // João Pessoa, PB
  initialZoom = 13,
}: InteractiveMapProps) {
  const mapContainer = useRef<HTMLDivElement>(null);
  const map = useRef<google.maps.Map | null>(null);
  const markers = useRef<google.maps.Marker[]>([]);
  const infoWindow = useRef<google.maps.InfoWindow | null>(null);
  const [selectedWork, setSelectedWork] = useState<Work | null>(null);
  const [filteredWorks, setFilteredWorks] = useState<Work[]>(works);
  const [statusFilter, setStatusFilter] = useState<'all' | 'completed' | 'ongoing' | 'planned'>('all');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  // Inicializar mapa
  useEffect(() => {
    if (!mapContainer.current) return;

    const mapOptions: google.maps.MapOptions = {
      zoom: initialZoom,
      center: initialCenter,
      mapTypeControl: true,
      fullscreenControl: true,
      streetViewControl: true,
      zoomControl: true,
      styles: [
        {
          featureType: 'water',
          elementType: 'geometry',
          stylers: [{ color: '#e9e9e9' }, { lightness: 17 }],
        },
        {
          featureType: 'landscape',
          elementType: 'geometry',
          stylers: [{ color: '#f3f3f3' }, { lightness: 20 }],
        },
      ],
    };

    map.current = new google.maps.Map(mapContainer.current, mapOptions);
    infoWindow.current = new google.maps.InfoWindow();

    return () => {
      // Cleanup
    };
  }, []);

  // Atualizar marcadores quando obras mudam
  useEffect(() => {
    if (!map.current) return;

    // Limpar marcadores antigos
    markers.current.forEach((marker) => marker.setMap(null));
    markers.current = [];

    // Adicionar novos marcadores
    filteredWorks.forEach((work) => {
      const marker = new google.maps.Marker({
        position: { lat: work.latitude, lng: work.longitude },
        map: map.current,
        title: work.name,
        icon: {
          path: google.maps.SymbolPath.CIRCLE,
          scale: 12,
          fillColor: statusColors[work.status],
          fillOpacity: 1,
          strokeColor: '#fff',
          strokeWeight: 2,
        },
      });

      marker.addListener('click', () => {
        setSelectedWork(work);
        onMarkerClick?.(work);

        // Centralizar no marcador
        map.current?.panTo(marker.getPosition()!);
        map.current?.setZoom(16);
      });

      markers.current.push(marker);
    });

    // Ajustar zoom para mostrar todos os marcadores
    if (filteredWorks.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      filteredWorks.forEach((work) => {
        bounds.extend({ lat: work.latitude, lng: work.longitude });
      });
      map.current.fitBounds(bounds, 50);
    }
  }, [filteredWorks]);

  // Aplicar filtros
  useEffect(() => {
    let filtered = works;

    if (statusFilter !== 'all') {
      filtered = filtered.filter((work) => work.status === statusFilter);
    }

    if (typeFilter !== 'all') {
      filtered = filtered.filter((work) => work.type === typeFilter);
    }

    setFilteredWorks(filtered);
  }, [statusFilter, typeFilter, works]);

  // Obter tipos únicos de obra
  const workTypes = Array.from(new Set(works.map((w) => w.type)));

  // Abrir rota no Google Maps
  const openRoute = (work: Work) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${work.latitude},${work.longitude}`;
    window.open(url, '_blank');
  };

  return (
    <div className="w-full h-full flex flex-col lg:flex-row gap-4 bg-gray-50 p-4 rounded-lg">
      {/* Mapa */}
      <div className="flex-1 flex flex-col">
        <div
          ref={mapContainer}
          className="flex-1 rounded-lg shadow-lg border border-gray-200 min-h-96 lg:min-h-screen"
        />
      </div>

      {/* Painel Lateral */}
      <div className="w-full lg:w-96 flex flex-col gap-4">
        {/* Filtros */}
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-200">
          <h3 className="font-bold text-gray-900 mb-3">Filtros</h3>

          {/* Filtro de Status */}
          <div className="mb-4">
            <label className="text-sm font-semibold text-gray-700 mb-2 block">Status</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
            >
              <option value="all">Todos</option>
              <option value="completed">Concluídas</option>
              <option value="ongoing">Em Andamento</option>
              <option value="planned">Planejadas</option>
            </select>
          </div>

          {/* Filtro de Tipo */}
          <div>
            <label className="text-sm font-semibold text-gray-700 mb-2 block">Tipo de Obra</label>
            <select
              value={typeFilter}
              onChange={(e) => setTypeFilter(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
            >
              <option value="all">Todos</option>
              {workTypes.map((type) => (
                <option key={type} value={type}>
                  {type}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Legenda */}
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-200">
          <h3 className="font-bold text-gray-900 mb-3">Legenda</h3>
          <div className="space-y-2">
            {Object.entries(statusColors).map(([status, color]) => (
              <div key={status} className="flex items-center gap-2">
                <div
                  className="w-4 h-4 rounded-full border-2 border-white"
                  style={{ backgroundColor: color }}
                />
                <span className="text-sm text-gray-700">{statusLabels[status as keyof typeof statusLabels]}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Card da Obra Selecionada */}
        {selectedWork && (
          <div className="bg-white rounded-lg shadow-md border border-gray-200 overflow-hidden">
            <div className="relative">
              {selectedWork.images.length > 0 ? (
                <img
                  src={selectedWork.images[0]}
                  alt={selectedWork.name}
                  className="w-full h-48 object-cover"
                />
              ) : (
                <div className="w-full h-48 bg-gray-200 flex items-center justify-center">
                  <MapPin className="w-8 h-8 text-gray-400" />
                </div>
              )}
              <button
                onClick={() => setSelectedWork(null)}
                className="absolute top-2 right-2 bg-white rounded-full p-1 shadow-md hover:bg-gray-100"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="absolute top-2 left-2 bg-white px-2 py-1 rounded-full text-xs font-semibold">
                <span
                  style={{
                    color: statusColors[selectedWork.status],
                  }}
                >
                  {statusLabels[selectedWork.status]}
                </span>
              </div>
            </div>

            <div className="p-4 space-y-3">
              <div>
                <h2 className="font-bold text-lg text-gray-900">{selectedWork.name}</h2>
                <p className="text-sm text-gray-600">{selectedWork.address}</p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-gray-500 font-semibold">Tipo</p>
                  <p className="text-gray-900">{selectedWork.type}</p>
                </div>
                <div>
                  <p className="text-gray-500 font-semibold">Status</p>
                  <p className="text-gray-900">{statusLabels[selectedWork.status]}</p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <p className="text-gray-500 font-semibold">Início</p>
                  <p className="text-gray-900">{new Date(selectedWork.startDate).toLocaleDateString('pt-BR')}</p>
                </div>
                <div>
                  <p className="text-gray-500 font-semibold">Término</p>
                  <p className="text-gray-900">{new Date(selectedWork.endDate).toLocaleDateString('pt-BR')}</p>
                </div>
              </div>

              <div>
                <p className="text-gray-500 font-semibold text-sm mb-1">Descrição</p>
                <p className="text-sm text-gray-700 line-clamp-3">{selectedWork.description}</p>
              </div>

              {selectedWork.images.length > 1 && (
                <div className="flex gap-2 overflow-x-auto">
                  {selectedWork.images.map((img, idx) => (
                    <img
                      key={idx}
                      src={img}
                      alt={`${selectedWork.name} ${idx}`}
                      className="w-16 h-16 object-cover rounded cursor-pointer hover:opacity-80"
                    />
                  ))}
                </div>
              )}

              <button
                onClick={() => openRoute(selectedWork)}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors"
              >
                <Navigation className="w-4 h-4" />
                Ver Rota
              </button>
            </div>
          </div>
        )}

        {/* Lista de Obras */}
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-200">
          <h3 className="font-bold text-gray-900 mb-3">Obras ({filteredWorks.length})</h3>
          <div className="space-y-2 max-h-64 overflow-y-auto">
            {filteredWorks.map((work) => (
              <button
                key={work.id}
                onClick={() => setSelectedWork(work)}
                className={`w-full text-left p-3 rounded-lg border-2 transition-all ${
                  selectedWork?.id === work.id
                    ? 'border-blue-600 bg-blue-50'
                    : 'border-gray-200 hover:border-gray-300'
                }`}
              >
                <div className="flex items-start gap-2">
                  <div
                    className="w-3 h-3 rounded-full mt-1 flex-shrink-0"
                    style={{ backgroundColor: statusColors[work.status] }}
                  />
                  <div className="flex-1 min-w-0">
                    <p className="font-semibold text-gray-900 truncate text-sm">{work.name}</p>
                    <p className="text-xs text-gray-600 truncate">{work.type}</p>
                  </div>
                </div>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
