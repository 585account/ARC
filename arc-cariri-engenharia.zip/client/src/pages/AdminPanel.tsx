import { useState, useEffect } from 'react';
import { ArrowLeft, Image as ImageIcon, Plus, Trash2, Edit2, MapPin } from 'lucide-react';
import { Link } from 'wouter';
import { toast } from 'sonner';
import DragDropUpload from '@/components/DragDropUpload';
import EditableText from '@/components/EditableText';
import { Button } from '@/components/ui/button';

interface UploadedFile {
  id: string;
  file: File;
  preview: string;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
  uploadedUrl?: string;
}

interface PortfolioItem {
  id: string;
  title: string;
  description: string;
  imageUrls: string[];
}

interface OngoingWork {
  id: string;
  title: string;
  location: string;
  stage: string;
  completion: string;
  imageUrls: string[];
}

export default function AdminPanel() {
  const [activeTab, setActiveTab] = useState<'portfolio' | 'works'>('portfolio');
  
  // Carregar dados do localStorage ou usar valores padrão
  const [portfolioItems, setPortfolioItems] = useState<PortfolioItem[]>(() => {
    const saved = localStorage.getItem('portfolioItems');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Erro ao carregar portfólio:', e);
      }
    }
    return [
      {
        id: '1',
        title: 'Casa Moderna - Projeto A',
        description: 'Residência de 280m² com design contemporâneo e acabamento premium.',
        imageUrls: ['https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/portfolio-completed-house-2eEf7up3fPZUBGj9bKc2wr.webp'],
      },
      {
        id: '2',
        title: 'Casa Elegante - Projeto B',
        description: 'Projeto residencial de 320m² com acabamento sofisticado e moderno.',
        imageUrls: ['https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/portfolio-modern-design-KLrMeZ95x4Zj2crViaNwFq.webp'],
      },
    ];
  });

  const [ongoingWorks, setOngoingWorks] = useState<OngoingWork[]>(() => {
    const saved = localStorage.getItem('ongoingWorks');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        console.error('Erro ao carregar obras:', e);
      }
    }
    return [
      {
        id: '1',
        title: 'Residência Moderna - Crato',
        location: 'Crato – Ceará',
        stage: 'Estrutura',
        completion: 'Junho 2026',
        imageUrls: ['https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/hero-construction-DWyQk5ggbX3fcWgYk87BLM.webp'],
      },
    ];
  });

  const [newPortfolioTitle, setNewPortfolioTitle] = useState('');
  const [newPortfolioDesc, setNewPortfolioDesc] = useState('');
  const [newPortfolioImage, setNewPortfolioImage] = useState('');

  const [newWorkTitle, setNewWorkTitle] = useState('');
  const [newWorkLocation, setNewWorkLocation] = useState('');
  const [newWorkStage, setNewWorkStage] = useState('Fundação');
  const [newWorkCompletion, setNewWorkCompletion] = useState('');
  const [newWorkImage, setNewWorkImage] = useState('');

  // Carregar dados da API ao montar
  useEffect(() => {
    const loadData = async () => {
      try {
        const [portfolioRes, worksRes] = await Promise.all([
          fetch('/api/portfolio'),
          fetch('/api/works')
        ]);
        const portfolioData = await portfolioRes.json();
        const worksData = await worksRes.json();
        if (portfolioData.length > 0) setPortfolioItems(portfolioData);
        if (worksData.length > 0) setOngoingWorks(worksData);
      } catch (error) {
        console.error('Erro ao carregar dados:', error);
      }
    };
    loadData();
  }, []);

  // Salvar portfólio no localStorage sempre que mudar
  useEffect(() => {
    localStorage.setItem('portfolioItems', JSON.stringify(portfolioItems));
  }, [portfolioItems]);

  // Salvar obras no localStorage sempre que mudar
  useEffect(() => {
    localStorage.setItem('ongoingWorks', JSON.stringify(ongoingWorks));
  }, [ongoingWorks]);

  const handlePortfolioUpload = async (files: UploadedFile[]) => {
    const imageUrls: string[] = [];
    let loadedCount = 0;
    
    for (const file of files) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = e.target?.result as string;
        imageUrls.push(imageData);
        loadedCount++;
        
        if (loadedCount === files.length) {
          setNewPortfolioImage(imageUrls[0]);
        }
      };
      reader.readAsDataURL(file.file);
    }
  };

  const handleWorkUpload = async (files: UploadedFile[]) => {
    const imageUrls: string[] = [];
    let loadedCount = 0;
    
    for (const file of files) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageData = e.target?.result as string;
        imageUrls.push(imageData);
        loadedCount++;
        
        if (loadedCount === files.length) {
          setNewWorkImage(imageUrls[0]);
        }
      };
      reader.readAsDataURL(file.file);
    }
  };

  const addPortfolioItem = async () => {
    if (!newPortfolioTitle || !newPortfolioDesc || !newPortfolioImage) {
      toast.error('Preencha todos os campos');
      return;
    }

    const newItem: PortfolioItem = {
      id: Date.now().toString(),
      title: newPortfolioTitle,
      description: newPortfolioDesc,
      imageUrls: newPortfolioImage ? [newPortfolioImage] : [],
    };

    try {
      const response = await fetch('/api/portfolio', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newItem),
      });
      const savedItem = await response.json();
      setPortfolioItems([...portfolioItems, savedItem]);
      setNewPortfolioTitle('');
      setNewPortfolioDesc('');
      setNewPortfolioImage('');
      toast.success('Projeto adicionado com sucesso! ✨');
    } catch (error) {
      console.error('Erro ao salvar portfólio:', error);
      toast.error('Erro ao salvar portfólio');
    }
  };

  const addOngoingWork = async () => {
    if (!newWorkTitle || !newWorkLocation || !newWorkCompletion || !newWorkImage) {
      toast.error('Preencha todos os campos');
      return;
    }

    const newWork: OngoingWork = {
      id: Date.now().toString(),
      title: newWorkTitle,
      location: newWorkLocation,
      stage: newWorkStage,
      completion: newWorkCompletion,
      imageUrls: newWorkImage ? [newWorkImage] : [],
    };

    try {
      const response = await fetch('/api/works', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newWork),
      });
      const savedWork = await response.json();
      setOngoingWorks([...ongoingWorks, savedWork]);
      setNewWorkTitle('');
      setNewWorkLocation('');
      setNewWorkStage('Fundação');
      setNewWorkCompletion('');
      setNewWorkImage('');
      toast.success('Obra adicionada com sucesso! 🏗️');
    } catch (error) {
      console.error('Erro ao salvar obra:', error);
      toast.error('Erro ao salvar obra');
    }
  };

  const deletePortfolioItem = async (id: string) => {
    try {
      await fetch(`/api/portfolio/${id}`, { method: 'DELETE' });
      setPortfolioItems(portfolioItems.filter((item) => item.id !== id));
      toast.success('Projeto removido com sucesso!');
    } catch (error) {
      console.error('Erro ao deletar portfólio:', error);
      toast.error('Erro ao remover projeto');
    }
  };

  const deleteOngoingWork = async (id: string) => {
    try {
      await fetch(`/api/works/${id}`, { method: 'DELETE' });
      setOngoingWorks(ongoingWorks.filter((work) => work.id !== id));
      toast.success('Obra removida com sucesso!');
    } catch (error) {
      console.error('Erro ao deletar obra:', error);
      toast.error('Erro ao remover obra');
    }
  };

  const updatePortfolioItem = async (id: string, field: string, value: string) => {
    const item = portfolioItems.find((item) => item.id === id);
    if (!item) return;
    
    const updated = { ...item, [field]: value };
    try {
      await fetch(`/api/portfolio/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
      setPortfolioItems(
        portfolioItems.map((item) =>
          item.id === id ? updated : item
        )
      );
      toast.success('Projeto atualizado com sucesso! ✏️');
    } catch (error) {
      console.error('Erro ao atualizar portfólio:', error);
      toast.error('Erro ao atualizar projeto');
    }
  };

  const updateOngoingWork = async (id: string, field: string, value: string) => {
    const work = ongoingWorks.find((work) => work.id === id);
    if (!work) return;
    
    const updated = { ...work, [field]: value };
    try {
      await fetch(`/api/works/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updated),
      });
      setOngoingWorks(
        ongoingWorks.map((work) =>
          work.id === id ? updated : work
        )
      );
      toast.success('Obra atualizada com sucesso! ✏️');
    } catch (error) {
      console.error('Erro ao atualizar obra:', error);
      toast.error('Erro ao atualizar obra');
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/">
              <a className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-5 h-5" />
                Voltar
              </a>
            </Link>
            <h1 className="text-2xl font-bold text-gray-900">Painel de Administração</h1>
          </div>
          <Link href="/admin/mapa">
            <a className="flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg font-medium transition-colors">
              <MapPin className="w-4 h-4" />
              Gerenciar Mapa
            </a>
          </Link>
        </div>
      </div>

      {/* Tabs */}
      <div className="bg-white border-b border-gray-200">
        <div className="max-w-6xl mx-auto px-4">
          <div className="flex gap-8">
            <button
              onClick={() => setActiveTab('portfolio')}
              className={`py-4 px-2 font-medium border-b-2 transition-colors ${
                activeTab === 'portfolio'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5" />
                Portfólio
              </div>
            </button>
            <button
              onClick={() => setActiveTab('works')}
              className={`py-4 px-2 font-medium border-b-2 transition-colors ${
                activeTab === 'works'
                  ? 'border-blue-600 text-blue-600'
                  : 'border-transparent text-gray-600 hover:text-gray-900'
              }`}
            >
              <div className="flex items-center gap-2">
                <ImageIcon className="w-5 h-5" />
                Obras em Andamento
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {activeTab === 'portfolio' && (
          <div className="space-y-8">
            {/* Add Portfolio Item */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Adicionar Projeto ao Portfólio</h2>

              <div className="space-y-6">
                {/* Upload Area */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-3">
                    Imagem do Projeto *
                  </label>
                  <DragDropUpload
                    onFilesSelected={handlePortfolioUpload}
                    maxFiles={20}
                    multiple={true}
                  />
                  {newPortfolioImage && (
                    <div className="mt-4">
                      <img
                        src={newPortfolioImage}
                        alt="Preview"
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    </div>
                  )}
                </div>

                {/* Form Fields */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Título do Projeto *
                  </label>
                  <input
                    type="text"
                    value={newPortfolioTitle}
                    onChange={(e) => setNewPortfolioTitle(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    placeholder="Ex: Casa Moderna - Projeto A"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Descrição *
                  </label>
                  <textarea
                    value={newPortfolioDesc}
                    onChange={(e) => setNewPortfolioDesc(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 resize-none"
                    rows={3}
                    placeholder="Descreva o projeto..."
                  />
                </div>

                <Button
                  onClick={addPortfolioItem}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Projeto
                </Button>
              </div>
            </div>

            {/* Portfolio Items List */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Projetos ({portfolioItems.length})</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {portfolioItems.map((item) => (
                  <div
                    key={item.id}
                    className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
                  >
                    <img
                      src={item.imageUrls[0] || ''}
                      alt={item.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-4 space-y-3">
                      <div>
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                          Título
                        </label>
                        <EditableText
                          value={item.title}
                          onSave={(newValue) => updatePortfolioItem(item.id, 'title', newValue)}
                          placeholder="Clique para editar"
                          displayClassName="font-bold text-gray-900"
                        />
                      </div>

                      <div>
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                          Descrição
                        </label>
                        <EditableText
                          value={item.description}
                          onSave={(newValue) => updatePortfolioItem(item.id, 'description', newValue)}
                          placeholder="Clique para editar"
                          displayClassName="text-sm text-gray-600"
                        />
                      </div>

                      <button
                        onClick={() => deletePortfolioItem(item.id)}
                        className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg font-medium transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                        Remover
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'works' && (
          <div className="space-y-8">
            {/* Add Ongoing Work */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Adicionar Obra em Andamento</h2>

              <div className="space-y-6">
                {/* Upload Area */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-3">
                    Imagem da Obra *
                  </label>
                  <DragDropUpload
                    onFilesSelected={handleWorkUpload}
                    maxFiles={20}
                    multiple={true}
                  />
                  {newWorkImage && (
                    <div className="mt-4">
                      <img
                        src={newWorkImage}
                        alt="Preview"
                        className="w-full h-48 object-cover rounded-lg"
                      />
                    </div>
                  )}
                </div>

                {/* Form Fields */}
                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Título da Obra *
                  </label>
                  <input
                    type="text"
                    value={newWorkTitle}
                    onChange={(e) => setNewWorkTitle(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    placeholder="Ex: Residência Moderna - Crato"
                  />
                </div>

                <div>
                  <label className="block text-sm font-semibold text-gray-900 mb-2">
                    Localização *
                  </label>
                  <input
                    type="text"
                    value={newWorkLocation}
                    onChange={(e) => setNewWorkLocation(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    placeholder="Ex: Crato – Ceará"
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-2">
                      Etapa da Construção *
                    </label>
                    <select
                      value={newWorkStage}
                      onChange={(e) => setNewWorkStage(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                    >
                      <option value="Fundação">Fundação</option>
                      <option value="Estrutura">Estrutura</option>
                      <option value="Acabamento">Acabamento</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-900 mb-2">
                      Previsão de Conclusão *
                    </label>
                    <input
                      type="text"
                      value={newWorkCompletion}
                      onChange={(e) => setNewWorkCompletion(e.target.value)}
                      className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                      placeholder="Ex: Junho 2026"
                    />
                  </div>
                </div>

                <Button
                  onClick={addOngoingWork}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Adicionar Obra
                </Button>
              </div>
            </div>

            {/* Ongoing Works List */}
            <div className="bg-white rounded-lg p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Obras em Andamento ({ongoingWorks.length})</h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {ongoingWorks.map((work) => (
                  <div
                    key={work.id}
                    className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
                  >
                    <img
                      src={work.imageUrls[0] || ''}
                      alt={work.title}
                      className="w-full h-48 object-cover"
                    />
                    <div className="p-4 space-y-3">
                      <div>
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                          Título
                        </label>
                        <EditableText
                          value={work.title}
                          onSave={(newValue) => updateOngoingWork(work.id, 'title', newValue)}
                          placeholder="Clique para editar"
                          displayClassName="font-bold text-gray-900"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                            Localização
                          </label>
                          <EditableText
                            value={work.location}
                            onSave={(newValue) => updateOngoingWork(work.id, 'location', newValue)}
                            placeholder="Clique para editar"
                            displayClassName="text-sm text-gray-600"
                          />
                        </div>

                        <div>
                          <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                            Etapa
                          </label>
                          <select
                            value={work.stage}
                            onChange={(e) => updateOngoingWork(work.id, 'stage', e.target.value)}
                            className="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:border-blue-500"
                          >
                            <option value="Fundação">Fundação</option>
                            <option value="Estrutura">Estrutura</option>
                            <option value="Acabamento">Acabamento</option>
                          </select>
                        </div>
                      </div>

                      <div>
                        <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                          Previsão
                        </label>
                        <EditableText
                          value={work.completion}
                          onSave={(newValue) => updateOngoingWork(work.id, 'completion', newValue)}
                          placeholder="Clique para editar"
                          displayClassName="text-sm text-gray-600"
                        />
                      </div>

                      <button
                        onClick={() => deleteOngoingWork(work.id)}
                        className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg font-medium transition-colors"
                      >
                        <Trash2 className="w-4 h-4" />
                        Remover
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
