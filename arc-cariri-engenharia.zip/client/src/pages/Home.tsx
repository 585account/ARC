import { CheckCircle, Award, Clock, Users, ArrowRight, Star, MapPin, Phone, Mail, MessageCircle } from 'lucide-react';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import { useState, useEffect } from 'react';

export default function Home() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    project: '',
    message: '',
  });

  const [portfolioItems, setPortfolioItems] = useState<any[]>([]);
  const [ongoingWorksItems, setOngoingWorksItems] = useState<any[]>([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [portfolioRes, worksRes] = await Promise.all([
          fetch('/api/portfolio'),
          fetch('/api/works')
        ]);
        const portfolioData = await portfolioRes.json();
        const worksData = await worksRes.json();
        setPortfolioItems(portfolioData);
        setOngoingWorksItems(worksData);
      } catch (error) {
        console.error('Erro ao carregar dados da API:', error);
      }
    };
    loadData();
    const interval = setInterval(loadData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleFormChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate form submission
    alert('Obrigado! Entraremos em contato em breve.');
    setFormData({ name: '', email: '', phone: '', project: '', message: '' });
  };

  const services = [
    {
      title: 'Construção de Casas',
      description: 'Projetos residenciais modernos e personalizados, desde o planejamento até a entrega final.',
      icon: '🏠',
    },
    {
      title: 'Gerenciamento de Obras',
      description: 'Acompanhamento completo do projeto com cronograma, orçamento e controle de qualidade.',
      icon: '📋',
    },
    {
      title: 'Projetos Residenciais',
      description: 'Desenvolvimento de projetos arquitetônicos e estruturais personalizados.',
      icon: '🎨',
    },
    {
      title: 'Reformas e Ampliações',
      description: 'Modernização e expansão de imóveis existentes com qualidade garantida.',
      icon: '🔨',
    },
    {
      title: 'Consultoria Técnica',
      description: 'Orientação especializada em todas as fases do projeto residencial.',
      icon: '👨‍💼',
    },
    {
      title: 'Acompanhamento Técnico',
      description: 'Supervisão contínua da obra para garantir qualidade e segurança.',
      icon: '✓',
    },
  ];

  const differentials = [
    {
      icon: <Award className="w-8 h-8" />,
      title: 'Qualidade na Execução',
      description: 'Materiais premium e mão de obra especializada em cada projeto.',
    },
    {
      icon: <Clock className="w-8 h-8" />,
      title: 'Cumprimento de Prazos',
      description: 'Cronograma rigoroso e entrega dentro do prazo acordado.',
    },
    {
      icon: <Users className="w-8 h-8" />,
      title: 'Acompanhamento Técnico',
      description: 'Equipe dedicada acompanhando cada etapa da construção.',
    },
    {
      icon: <CheckCircle className="w-8 h-8" />,
      title: 'Transparência com Cliente',
      description: 'Comunicação clara e relatórios periódicos do andamento da obra.',
    },
  ];

  const portfolio = portfolioItems.length > 0 ? portfolioItems.map((item: any) => ({
    title: item.title,
    description: item.description,
    image: item.imageUrls && item.imageUrls.length > 0 ? item.imageUrls[0] : '',
  })) : [
    {
      title: 'Casa Moderna - Projeto A',
      description: 'Residência de 280m² com design contemporâneo e acabamento premium.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/portfolio-completed-house-2eEf7up3fPZUBGj9bKc2wr.webp',
    },
    {
      title: 'Casa Elegante - Projeto B',
      description: 'Projeto residencial de 320m² com acabamento sofisticado e moderno.',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/portfolio-modern-design-KLrMeZ95x4Zj2crViaNwFq.webp',
    },
    {
      title: 'Reforma Residencial',
      description: 'Modernização completa de residência com ampliação de 150m².',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/hero-construction-DWyQk5ggbX3fcWgYk87BLM.webp',
    },
  ];

  const ongoingWorks = ongoingWorksItems.length > 0 ? ongoingWorksItems.map((item: any) => ({
    title: item.title,
    location: item.location,
    stage: item.stage,
    completion: item.completion,
    image: item.imageUrls && item.imageUrls.length > 0 ? item.imageUrls[0] : '',
  })) : [
    {
      title: 'Residência Moderna - Crato',
      location: 'Crato – Ceará',
      stage: 'Estrutura',
      completion: 'Junho 2026',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/hero-construction-DWyQk5ggbX3fcWgYk87BLM.webp',
    },
    {
      title: 'Casa Residencial - Crato',
      location: 'Crato – Ceará',
      stage: 'Acabamento',
      completion: 'Maio 2026',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/portfolio-completed-house-2eEf7up3fPZUBGj9bKc2wr.webp',
    },
    {
      title: 'Projeto Residencial - Crato',
      location: 'Crato – Ceará',
      stage: 'Fundação',
      completion: 'Julho 2026',
      image: 'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/portfolio-modern-design-KLrMeZ95x4Zj2crViaNwFq.webp',
    },
  ];

  const getStageColor = (stage: string) => {
    switch (stage.toLowerCase()) {
      case 'fundação':
        return 'bg-blue-100 text-blue-800';
      case 'estrutura':
        return 'bg-yellow-100 text-yellow-800';
      case 'acabamento':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-white">
      <Header />

      {/* Hero Section */}
      <section id="home" className="relative h-screen md:h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img
            src="https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/hero-construction-DWyQk5ggbX3fcWgYk87BLM.webp"
            alt="Construção residencial"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black/50"></div>
        </div>

        <div className="container relative z-10">
          <div className="max-w-2xl">
            <h1 className="text-white text-4xl md:text-5xl lg:text-6xl font-bold mb-6 leading-tight">
              ARC Cariri Engenharia
            </h1>
            <p className="text-white text-xl md:text-2xl mb-8 font-semibold">
              Construindo qualidade, segurança e confiança.
            </p>
            <p className="text-blue-100 text-lg mb-8 max-w-xl">
              Especialista em construção de casas, gerenciamento de obras e projetos residenciais com excelência.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="#contact" className="btn-primary bg-white text-primary hover:bg-gray-100">
                Solicitar Orçamento
              </a>
              <a href="#services" className="btn-outline border-white text-white hover:bg-white hover:text-primary">
                Conheça Nossos Serviços
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="section-padding bg-gray-50">
        <div className="container">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-primary mb-6">Sobre a ARC Cariri Engenharia</h2>
              <p className="text-gray-700 mb-4 leading-relaxed">
                A ARC Cariri Engenharia é uma empresa especializada em construção residencial, com anos de experiência em projetos de alta qualidade na região do Cariri.
              </p>
              <p className="text-gray-700 mb-6 leading-relaxed">
                Nossa missão é construir residências que combinam qualidade, segurança e confiança, sempre respeitando os prazos e orçamentos acordados com nossos clientes.
              </p>

              <div className="space-y-4 mb-8">
                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Missão</h4>
                  <p className="text-gray-700">Executar projetos residenciais com excelência, qualidade e transparência.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Visão</h4>
                  <p className="text-gray-700">Ser referência em construção residencial na região do Cariri.</p>
                </div>
                <div>
                  <h4 className="font-bold text-gray-900 mb-2">Valores</h4>
                  <p className="text-gray-700">Qualidade, integridade, segurança e satisfação do cliente.</p>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="bg-white p-6 rounded-lg shadow-lg text-center">
                <div className="text-4xl font-bold text-primary mb-2">50+</div>
                <p className="text-gray-700 font-semibold">Projetos Concluídos</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-lg text-center">
                <div className="text-4xl font-bold text-primary mb-2">15+</div>
                <p className="text-gray-700 font-semibold">Anos de Experiência</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-lg text-center">
                <div className="text-4xl font-bold text-primary mb-2">100%</div>
                <p className="text-gray-700 font-semibold">Clientes Satisfeitos</p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow-lg text-center">
                <div className="text-4xl font-bold text-primary mb-2">10k+</div>
                <p className="text-gray-700 font-semibold">m² Construídos</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="section-padding">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-primary mb-4">Nossos Serviços</h2>
            <p className="text-gray-700 text-lg max-w-2xl mx-auto">
              Oferecemos soluções completas para seus projetos residenciais, desde o planejamento até a entrega final.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-gray-50 p-8 rounded-lg card-shadow hover:bg-white transition-colors">
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3 className="text-xl font-bold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-700">{service.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Ongoing Works Section */}
      <section id="ongoing-works" className="section-padding bg-gray-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-primary mb-4">Obras em Andamento</h2>
            <p className="text-gray-700 text-lg max-w-2xl mx-auto">
              Acompanhe nossos projetos em execução na região do Cariri.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {ongoingWorks.map((work, index) => (
              <div key={index} className="bg-white rounded-lg overflow-hidden card-shadow">
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={work.image}
                    alt={work.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-3">{work.title}</h3>
                  
                  <div className="space-y-3 mb-4">
                    <div className="flex items-start space-x-2">
                      <MapPin size={18} className="text-primary mt-0.5 flex-shrink-0" />
                      <p className="text-gray-700 text-sm">{work.location}</p>
                    </div>
                    
                    <div>
                      <p className="text-gray-600 text-xs font-semibold mb-1">Etapa Atual</p>
                      <span className={`inline-block px-3 py-1 rounded-full text-sm font-semibold ${getStageColor(work.stage)}`}>
                        {work.stage}
                      </span>
                    </div>
                    
                    <div>
                      <p className="text-gray-600 text-xs font-semibold">Previsão de Conclusão</p>
                      <p className="text-gray-900 font-semibold">{work.completion}</p>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Portfolio Section */}
      <section id="portfolio" className="section-padding">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-primary mb-4">Portfólio de Obras</h2>
            <p className="text-gray-700 text-lg max-w-2xl mx-auto">
              Conheça alguns de nossos projetos concluídos com sucesso.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {portfolio.map((project, index) => (
              <div key={index} className="bg-gray-50 rounded-lg overflow-hidden card-shadow">
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-300"
                  />
                </div>
                <div className="p-6">
                  <h3 className="text-lg font-bold text-gray-900 mb-2">{project.title}</h3>
                  <p className="text-gray-700 text-sm">{project.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Differentials Section */}
      <section className="section-padding bg-gray-50">
        <div className="container">
          <div className="text-center mb-16">
            <h2 className="text-primary mb-4">Por Que Escolher a ARC Cariri?</h2>
            <p className="text-gray-700 text-lg max-w-2xl mx-auto">
              Nossos diferenciais garantem a qualidade e satisfação em cada projeto.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {differentials.map((diff, index) => (
              <div key={index} className="text-center">
                <div className="flex justify-center mb-4">
                  <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center text-primary">
                    {diff.icon}
                  </div>
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{diff.title}</h3>
                <p className="text-gray-700 text-sm">{diff.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="section-padding">
        <div className="container">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-12">
              <h2 className="text-primary mb-4">Solicite um Orçamento</h2>
              <p className="text-gray-700 text-lg">
                Preencha o formulário abaixo e nossa equipe entrará em contato para discutir seu projeto.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
              {/* Form */}
              <form onSubmit={handleFormSubmit} className="space-y-6">
                <div>
                  <label className="block text-gray-900 font-semibold mb-2">Nome Completo</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    placeholder="Seu nome"
                  />
                </div>

                <div>
                  <label className="block text-gray-900 font-semibold mb-2">Email</label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    placeholder="seu@email.com"
                  />
                </div>

                <div>
                  <label className="block text-gray-900 font-semibold mb-2">Telefone</label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    placeholder="(88) 9 9999-9999"
                  />
                </div>

                <div>
                  <label className="block text-gray-900 font-semibold mb-2">Tipo de Projeto</label>
                  <select
                    name="project"
                    value={formData.project}
                    onChange={handleFormChange}
                    required
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                  >
                    <option value="">Selecione uma opção</option>
                    <option value="construcao">Construção de Casa</option>
                    <option value="reforma">Reforma e Ampliação</option>
                    <option value="gerenciamento">Gerenciamento de Obra</option>
                    <option value="consultoria">Consultoria Técnica</option>
                    <option value="outro">Outro</option>
                  </select>
                </div>

                <div>
                  <label className="block text-gray-900 font-semibold mb-2">Mensagem</label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleFormChange}
                    rows={4}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    placeholder="Descreva seu projeto..."
                  ></textarea>
                </div>

                <button type="submit" className="btn-primary w-full">
                  Enviar Solicitação
                </button>
              </form>

              {/* Contact Info */}
              <div className="space-y-8">
                <div className="bg-gray-50 p-8 rounded-lg">
                  <h3 className="text-lg font-bold text-gray-900 mb-6">Informações de Contato</h3>

                  <div className="space-y-6">
                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <MapPin className="text-primary" size={24} />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 mb-1">Localização</h4>
                        <p className="text-gray-700">Crato – Ceará, Brasil</p>
                      </div>
                    </div>

                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Phone className="text-primary" size={24} />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 mb-1">Telefone</h4>
                        <a href="https://wa.me/88988883633" target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary/80 transition-colors">
                          (88) 98888-3633
                        </a>
                      </div>
                    </div>

                    <div className="flex items-start space-x-4">
                      <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                        <Mail className="text-primary" size={24} />
                      </div>
                      <div>
                        <h4 className="font-bold text-gray-900 mb-1">Email</h4>
                        <a href="mailto:contato@arccariri.com.br" className="text-primary hover:text-primary/80 transition-colors">
                          contato@arccariri.com.br
                        </a>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="bg-primary text-white p-8 rounded-lg">
                  <h3 className="text-lg font-bold mb-4">Contato via WhatsApp</h3>
                  <p className="text-blue-100 mb-6">
                    Clique no botão abaixo para conversar conosco via WhatsApp e obter uma resposta rápida.
                  </p>
                  <a
                    href="https://wa.me/88988883633?text=Olá! Gostaria de solicitar um orçamento para meu projeto residencial."
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center space-x-2 bg-white text-primary px-6 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
                  >
                    <MessageCircle size={20} />
                    <span>Abrir WhatsApp</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
