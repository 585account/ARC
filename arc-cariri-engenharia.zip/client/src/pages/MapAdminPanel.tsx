import { useState } from 'react';
import { ArrowLeft, Plus, Trash2, MapPin } from 'lucide-react';
import { Link } from 'wouter';
import DragDropUpload from '@/components/DragDropUpload';
import EditableText from '@/components/EditableText';
import { Button } from '@/components/ui/button';

interface UploadedFile {
  id: string;
  file: File;
  preview: string;
  status: 'pending' | 'uploading' | 'success' | 'error';
  error?: string;
  uploadedUrl?: string;
}

interface Work {
  id: string;
  name: string;
  type: string;
  status: 'completed' | 'ongoing' | 'planned';
  latitude: number;
  longitude: number;
  startDate: string;
  endDate: string;
  description: string;
  images: string[];
  address: string;
}

export default function MapAdminPanel() {
  const [works, setWorks] = useState<Work[]>([
    {
      id: '1',
      name: 'Residência Moderna - Crato',
      type: 'Construção Residencial',
      status: 'ongoing',
      latitude: -7.2383,
      longitude: -39.3167,
      startDate: '2025-01-15',
      endDate: '2026-06-30',
      description:
        'Construção de residência moderna com 280m², incluindo estrutura de concreto, acabamento premium e sistemas de automação.',
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/hero-construction-DWyQk5ggbX3fcWgYk87BLM.webp',
      ],
      address: 'Crato – Ceará, Brasil',
    },
  ]);

  const [newWork, setNewWork] = useState<{
    name: string;
    type: string;
    status: 'completed' | 'ongoing' | 'planned';
    latitude: number;
    longitude: number;
    startDate: string;
    endDate: string;
    description: string;
    images: string[];
    address: string;
  }>({
    name: '',
    type: '',
    status: 'ongoing',
    latitude: -7.1219,
    longitude: -34.8413,
    startDate: '',
    endDate: '',
    description: '',
    images: [],
    address: '',
  });

  const [newWorkImage, setNewWorkImage] = useState('');

  const workTypes = [
    'Construção Residencial',
    'Reforma e Ampliação',
    'Ampliação',
    'Consultoria Técnica',
  ];

  const handleWorkUpload = async (files: UploadedFile[]) => {
    for (const file of files) {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setNewWorkImage(imageUrl);
      };
      reader.readAsDataURL(file.file);
    }
  };

  const addWork = () => {
    if (
      !newWork.name ||
      !newWork.type ||
      !newWork.startDate ||
      !newWork.endDate ||
      !newWork.address ||
      !newWorkImage
    ) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    const work: Work = {
      id: Date.now().toString(),
      ...newWork,
      images: [newWorkImage],
    };

    setWorks([...works, work]);
    setNewWork({
      name: '',
      type: '',
      status: 'ongoing',
      latitude: -7.1219,
      longitude: -34.8413,
      startDate: '',
      endDate: '',
      description: '',
      images: [],
      address: '',
    });
    setNewWorkImage('');
  };

  const deleteWork = (id: string) => {
    setWorks(works.filter((work) => work.id !== id));
  };

  const updateWork = (id: string, field: string, value: any) => {
    setWorks(
      works.map((work) =>
        work.id === id ? { ...work, [field]: value } : work
      )
    );
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Link href="/admin">
              <a className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-5 h-5" />
                Voltar
              </a>
            </Link>
            <div className="flex items-center gap-2">
              <MapPin className="w-6 h-6 text-blue-600" />
              <h1 className="text-2xl font-bold text-gray-900">Gerenciar Mapa de Obras</h1>
            </div>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="max-w-6xl mx-auto px-4 py-8">
        {/* Add New Work */}
        <div className="bg-white rounded-lg p-6 border border-gray-200 mb-8">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Adicionar Nova Obra</h2>

          <div className="space-y-6">
            {/* Upload Area */}
            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-3">
                Imagem da Obra *
              </label>
              <DragDropUpload
                onFilesSelected={handleWorkUpload}
                maxFiles={1}
                multiple={false}
              />
              {newWorkImage && (
                <div className="mt-4">
                  <img
                    src={newWorkImage}
                    alt="Preview"
                    className="w-full h-48 object-cover rounded-lg"
                  />
                </div>
              )}
            </div>

            {/* Form Fields */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Nome da Obra *
                </label>
                <input
                  type="text"
                  value={newWork.name}
                  onChange={(e) => setNewWork({ ...newWork, name: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                  placeholder="Ex: Residência Moderna - Crato"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Tipo de Obra *
                </label>
                <select
                  value={newWork.type}
                  onChange={(e) => setNewWork({ ...newWork, type: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                >
                  <option value="">Selecione um tipo</option>
                  {workTypes.map((type) => (
                    <option key={type} value={type}>
                      {type}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Endereço/Localização *
              </label>
              <input
                type="text"
                value={newWork.address}
                onChange={(e) => setNewWork({ ...newWork, address: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                placeholder="Ex: Crato – Ceará, Brasil"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Latitude *
                </label>
                <input
                  type="number"
                  step="0.0001"
                  value={newWork.latitude}
                  onChange={(e) =>
                    setNewWork({ ...newWork, latitude: parseFloat(e.target.value) })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                  placeholder="-7.1219"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Longitude *
                </label>
                <input
                  type="number"
                  step="0.0001"
                  value={newWork.longitude}
                  onChange={(e) =>
                    setNewWork({ ...newWork, longitude: parseFloat(e.target.value) })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                  placeholder="-34.8413"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Status *
                </label>
                <select
                  value={newWork.status}
                  onChange={(e) =>
                    setNewWork({
                      ...newWork,
                      status: e.target.value as 'completed' | 'ongoing' | 'planned',
                    })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                >
                  <option value="completed">Concluída</option>
                  <option value="ongoing">Em Andamento</option>
                  <option value="planned">Planejada</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Data de Início *
                </label>
                <input
                  type="date"
                  value={newWork.startDate}
                  onChange={(e) => setNewWork({ ...newWork, startDate: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-900 mb-2">
                  Data de Término *
                </label>
                <input
                  type="date"
                  value={newWork.endDate}
                  onChange={(e) => setNewWork({ ...newWork, endDate: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-semibold text-gray-900 mb-2">
                Descrição
              </label>
              <textarea
                value={newWork.description}
                onChange={(e) => setNewWork({ ...newWork, description: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:border-blue-500 resize-none"
                rows={4}
                placeholder="Descreva os detalhes da obra..."
              />
            </div>

            <Button
              onClick={addWork}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white"
            >
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Obra
            </Button>
          </div>
        </div>

        {/* Works List */}
        <div className="bg-white rounded-lg p-6 border border-gray-200">
          <h2 className="text-xl font-bold text-gray-900 mb-6">Obras ({works.length})</h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {works.map((work) => (
              <div
                key={work.id}
                className="border border-gray-200 rounded-lg overflow-hidden hover:shadow-lg transition-shadow"
              >
                <img
                  src={work.images[0]}
                  alt={work.name}
                  className="w-full h-48 object-cover"
                />
                <div className="p-4 space-y-3">
                  <div>
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                      Nome
                    </label>
                    <EditableText
                      value={work.name}
                      onSave={(newValue) => updateWork(work.id, 'name', newValue)}
                      placeholder="Clique para editar"
                      displayClassName="font-bold text-gray-900"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                        Tipo
                      </label>
                      <select
                        value={work.type}
                        onChange={(e) => updateWork(work.id, 'type', e.target.value)}
                        className="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:border-blue-500"
                      >
                        {workTypes.map((type) => (
                          <option key={type} value={type}>
                            {type}
                          </option>
                        ))}
                      </select>
                    </div>

                    <div>
                      <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                        Status
                      </label>
                      <select
                        value={work.status}
                        onChange={(e) =>
                          updateWork(
                            work.id,
                            'status',
                            e.target.value
                          )
                        }
                        className="w-full px-2 py-1 border border-gray-300 rounded text-sm focus:outline-none focus:border-blue-500"
                      >
                        <option value="completed">Concluída</option>
                        <option value="ongoing">Em Andamento</option>
                        <option value="planned">Planejada</option>
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide">
                      Localização
                    </label>
                    <EditableText
                      value={work.address}
                      onSave={(newValue) => updateWork(work.id, 'address', newValue)}
                      placeholder="Clique para editar"
                      displayClassName="text-sm text-gray-600"
                    />
                  </div>

                  <div className="text-xs text-gray-500">
                    <p>
                      <strong>Coordenadas:</strong> {work.latitude.toFixed(4)}, {work.longitude.toFixed(4)}
                    </p>
                  </div>

                  <button
                    onClick={() => deleteWork(work.id)}
                    className="w-full flex items-center justify-center gap-2 px-3 py-2 bg-red-50 text-red-600 hover:bg-red-100 rounded-lg font-medium transition-colors"
                  >
                    <Trash2 className="w-4 h-4" />
                    Remover
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
