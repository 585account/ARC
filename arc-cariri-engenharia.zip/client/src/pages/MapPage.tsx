import { useState } from 'react';
import Header from '@/components/Header';
import Footer from '@/components/Footer';
import WhatsAppButton from '@/components/WhatsAppButton';
import InteractiveMap from '@/components/InteractiveMap';
import { MapPin } from 'lucide-react';

interface Work {
  id: string;
  name: string;
  type: string;
  status: 'completed' | 'ongoing' | 'planned';
  latitude: number;
  longitude: number;
  startDate: string;
  endDate: string;
  description: string;
  images: string[];
  address: string;
}

export default function MapPage() {
  // Dados de exemplo de obras
  const [works] = useState<Work[]>([
    {
      id: '1',
      name: 'Residência Moderna - Crato',
      type: 'Construção Residencial',
      status: 'ongoing',
      latitude: -7.2383,
      longitude: -39.3167,
      startDate: '2025-01-15',
      endDate: '2026-06-30',
      description:
        'Construção de residência moderna com 280m², incluindo estrutura de concreto, acabamento premium e sistemas de automação.',
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/hero-construction-DWyQk5ggbX3fcWgYk87BLM.webp',
      ],
      address: 'Crato – Ceará, Brasil',
    },
    {
      id: '2',
      name: 'Casa Elegante - João Pessoa',
      type: 'Construção Residencial',
      status: 'completed',
      latitude: -7.1219,
      longitude: -34.8413,
      startDate: '2024-03-01',
      endDate: '2025-09-30',
      description:
        'Residência de 320m² com design contemporâneo, acabamento sofisticado e áreas de lazer integradas.',
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/portfolio-completed-house-2eEf7up3fPZUBGj9bKc2wr.webp',
      ],
      address: 'João Pessoa – Paraíba, Brasil',
    },
    {
      id: '3',
      name: 'Reforma Residencial - Campina Grande',
      type: 'Reforma e Ampliação',
      status: 'ongoing',
      latitude: -7.2302,
      longitude: -35.8801,
      startDate: '2025-06-01',
      endDate: '2026-02-28',
      description:
        'Reforma completa de residência com ampliação de 150m², modernização de sistemas e atualização de acabamentos.',
      images: [
        'https://d2xsxph8kpxj0f.cloudfront.net/310519663103625792/VJv4tzxhEVobJeXR8qfcbc/portfolio-modern-design-KLrMeZ95x4Zj2crViaNwFq.webp',
      ],
      address: 'Campina Grande – Paraíba, Brasil',
    },
    {
      id: '4',
      name: 'Projeto Residencial - Guarabira',
      type: 'Construção Residencial',
      status: 'planned',
      latitude: -6.8667,
      longitude: -35.4833,
      startDate: '2026-03-01',
      endDate: '2026-12-31',
      description:
        'Novo projeto de construção residencial de 250m² com características modernas e sustentáveis.',
      images: [],
      address: 'Guarabira – Paraíba, Brasil',
    },
    {
      id: '5',
      name: 'Ampliação Comercial - Patos',
      type: 'Ampliação',
      status: 'planned',
      latitude: -7.0167,
      longitude: -37.2667,
      startDate: '2026-04-15',
      endDate: '2026-10-15',
      description: 'Ampliação de espaço comercial com 200m² de área adicional.',
      images: [],
      address: 'Patos – Paraíba, Brasil',
    },
  ]);

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header />

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-900 to-blue-700 text-white py-12">
        <div className="max-w-7xl mx-auto px-4">
          <div className="flex items-center gap-3 mb-4">
            <MapPin className="w-6 h-6" />
            <h1 className="text-3xl md:text-4xl font-bold">Mapa de Obras</h1>
          </div>
          <p className="text-blue-100 text-lg">
            Visualize todas as nossas obras em andamento, concluídas e planejadas no mapa interativo
          </p>
        </div>
      </section>

      {/* Mapa */}
      <section className="flex-1 py-8">
        <div className="max-w-7xl mx-auto px-4 h-full">
          <div className="bg-white rounded-lg shadow-lg overflow-hidden" style={{ height: '600px' }}>
            <InteractiveMap
              works={works}
              initialCenter={{ lat: -7.1219, lng: -34.8413 }}
              initialZoom={9}
            />
          </div>
        </div>
      </section>

      {/* Informações */}
      <section className="py-12 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4">
          <h2 className="text-2xl font-bold text-gray-900 mb-8">Sobre o Mapa</h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-green-500">
              <h3 className="font-bold text-gray-900 mb-2">Obras Concluídas</h3>
              <p className="text-gray-600 text-sm">
                Projetos finalizados com sucesso, demonstrando nossa experiência e qualidade.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-yellow-500">
              <h3 className="font-bold text-gray-900 mb-2">Em Andamento</h3>
              <p className="text-gray-600 text-sm">
                Obras em execução com acompanhamento técnico contínuo e transparência total.
              </p>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-md border-l-4 border-red-500">
              <h3 className="font-bold text-gray-900 mb-2">Planejadas</h3>
              <p className="text-gray-600 text-sm">
                Projetos futuros que demonstram nosso crescimento e compromisso com a região.
              </p>
            </div>
          </div>
        </div>
      </section>

      <Footer />
      <WhatsAppButton />
    </div>
  );
}
