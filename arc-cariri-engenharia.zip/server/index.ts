import express from "express";
import { createServer } from "http";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DATA_FILE = path.join(__dirname, "data.json");

// Funções auxiliares para gerenciar dados
function readData() {
  try {
    const data = fs.readFileSync(DATA_FILE, "utf-8");
    return JSON.parse(data);
  } catch (error) {
    return { portfolioItems: [], ongoingWorks: [] };
  }
}

function writeData(data: any) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2));
}

async function startServer() {
  const app = express();
  const server = createServer(app);

  // Middleware
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  // API Routes - DEVEM VIR ANTES DO CATCH-ALL
  app.get("/api/portfolio", (_req, res) => {
    const data = readData();
    res.json(data.portfolioItems || []);
  });

  app.post("/api/portfolio", (req, res) => {
    try {
      const data = readData();
      const newItem = {
        id: Date.now().toString(),
        ...req.body,
      };
      data.portfolioItems = data.portfolioItems || [];
      data.portfolioItems.push(newItem);
      writeData(data);
      res.json(newItem);
    } catch (error) {
      res.status(500).json({ error: "Erro ao salvar portfólio" });
    }
  });

  app.delete("/api/portfolio/:id", (req, res) => {
    try {
      const data = readData();
      data.portfolioItems = (data.portfolioItems || []).filter(
        (item: any) => item.id !== req.params.id
      );
      writeData(data);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Erro ao deletar portfólio" });
    }
  });

  app.put("/api/portfolio/:id", (req, res) => {
    try {
      const data = readData();
      const index = (data.portfolioItems || []).findIndex(
        (item: any) => item.id === req.params.id
      );
      if (index !== -1) {
        data.portfolioItems[index] = { ...data.portfolioItems[index], ...req.body };
        writeData(data);
        res.json(data.portfolioItems[index]);
      } else {
        res.status(404).json({ error: "Portfólio não encontrado" });
      }
    } catch (error) {
      res.status(500).json({ error: "Erro ao atualizar portfólio" });
    }
  });

  app.get("/api/works", (_req, res) => {
    const data = readData();
    res.json(data.ongoingWorks || []);
  });

  app.post("/api/works", (req, res) => {
    try {
      const data = readData();
      const newItem = {
        id: Date.now().toString(),
        ...req.body,
      };
      data.ongoingWorks = data.ongoingWorks || [];
      data.ongoingWorks.push(newItem);
      writeData(data);
      res.json(newItem);
    } catch (error) {
      res.status(500).json({ error: "Erro ao salvar obra" });
    }
  });

  app.delete("/api/works/:id", (req, res) => {
    try {
      const data = readData();
      data.ongoingWorks = (data.ongoingWorks || []).filter(
        (item: any) => item.id !== req.params.id
      );
      writeData(data);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Erro ao deletar obra" });
    }
  });

  app.put("/api/works/:id", (req, res) => {
    try {
      const data = readData();
      const index = (data.ongoingWorks || []).findIndex(
        (item: any) => item.id === req.params.id
      );
      if (index !== -1) {
        data.ongoingWorks[index] = { ...data.ongoingWorks[index], ...req.body };
        writeData(data);
        res.json(data.ongoingWorks[index]);
      } else {
        res.status(404).json({ error: "Obra não encontrada" });
      }
    } catch (error) {
      res.status(500).json({ error: "Erro ao atualizar obra" });
    }
  });

  // Serve static files from dist/public in production
  const staticPath =
    process.env.NODE_ENV === "production"
      ? path.resolve(__dirname, "public")
      : path.resolve(__dirname, "..", "dist", "public");
  app.use(express.static(staticPath));

  // Handle client-side routing - serve index.html for all routes
  // IMPORTANTE: Esta rota deve ser a ÚLTIMA, após todas as rotas de API
  app.get("*", (_req, res) => {
    const indexPath = path.join(staticPath, "index.html");
    if (fs.existsSync(indexPath)) {
      res.sendFile(indexPath);
    } else {
      res.status(404).json({ error: "index.html not found" });
    }
  });

  const port = process.env.PORT || 3000;
  server.listen(port, () => {
    console.log(`Server running on http://localhost:${port}/`);
  });
}

startServer().catch(console.error);
