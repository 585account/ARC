import { jsxLocPlugin } from "@builder.io/vite-plugin-jsx-loc";
import tailwindcss from "@tailwindcss/vite";
import react from "@vitejs/plugin-react";
import fs from "node:fs";
import path from "node:path";
import { defineConfig, type Plugin, type ViteDevServer } from "vite";
import { vitePluginManusRuntime } from "vite-plugin-manus-runtime";

// =============================================================================
// Manus Debug Collector - Vite Plugin
// Writes browser logs directly to files, trimmed when exceeding size limit
// =============================================================================

const PROJECT_ROOT = import.meta.dirname;
const LOG_DIR = path.join(PROJECT_ROOT, ".manus-logs");
const MAX_LOG_SIZE_BYTES = 1 * 1024 * 1024; // 1MB per log file
const TRIM_TARGET_BYTES = Math.floor(MAX_LOG_SIZE_BYTES * 0.6); // Trim to 60% to avoid constant re-trimming

type LogSource = "browserConsole" | "networkRequests" | "sessionReplay";

function ensureLogDir() {
  if (!fs.existsSync(LOG_DIR)) {
    fs.mkdirSync(LOG_DIR, { recursive: true });
  }
}

function trimLogFile(logPath: string, maxSize: number) {
  try {
    if (!fs.existsSync(logPath) || fs.statSync(logPath).size <= maxSize) {
      return;
    }

    const lines = fs.readFileSync(logPath, "utf-8").split("\n");
    const keptLines: string[] = [];
    let keptBytes = 0;

    // Keep newest lines (from end) that fit within 60% of maxSize
    const targetSize = TRIM_TARGET_BYTES;
    for (let i = lines.length - 1; i >= 0; i--) {
      const lineBytes = Buffer.byteLength(`${lines[i]}\n`, "utf-8");
      if (keptBytes + lineBytes > targetSize) break;
      keptLines.unshift(lines[i]);
      keptBytes += lineBytes;
    }

    fs.writeFileSync(logPath, keptLines.join("\n"), "utf-8");
  } catch {
    /* ignore trim errors */
  }
}

function writeToLogFile(source: LogSource, entries: unknown[]) {
  if (entries.length === 0) return;

  ensureLogDir();
  const logPath = path.join(LOG_DIR, `${source}.log`);

  // Format entries with timestamps
  const lines = entries.map((entry) => {
    const ts = new Date().toISOString();
    return `[${ts}] ${JSON.stringify(entry)}`;
  });

  // Append to log file
  fs.appendFileSync(logPath, `${lines.join("\n")}\n`, "utf-8");

  // Trim if exceeds max size
  trimLogFile(logPath, MAX_LOG_SIZE_BYTES);
}

/**
 * Vite plugin to collect browser debug logs
 * - POST /__manus__/logs: Browser sends logs, written directly to files
 * - Files: browserConsole.log, networkRequests.log, sessionReplay.log
 * - Auto-trimmed when exceeding 1MB (keeps newest entries)
 */
/**
 * Vite plugin para servir API de portfólio e obras
 */
function vitePluginApiServer(): Plugin {
  let dataFile = path.join(PROJECT_ROOT, "server", "data.json");

  function readData() {
    try {
      if (!fs.existsSync(dataFile)) {
        return { portfolioItems: [], ongoingWorks: [] };
      }
      const data = fs.readFileSync(dataFile, "utf-8");
      return JSON.parse(data);
    } catch (error) {
      return { portfolioItems: [], ongoingWorks: [] };
    }
  }

  function writeData(data: any) {
    const dir = path.dirname(dataFile);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    fs.writeFileSync(dataFile, JSON.stringify(data, null, 2));
  }

  return {
    name: "api-server",

    configureServer(server: ViteDevServer) {
      // GET /api/portfolio
      server.middlewares.use("/api/portfolio", (req, res, next) => {
        if (req.method === "GET") {
          const data = readData();
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(data.portfolioItems || []));
          return;
        }
        next();
      });

      // POST /api/portfolio
      server.middlewares.use("/api/portfolio", (req, res, next) => {
        if (req.method === "POST") {
          let body = "";
          req.on("data", (chunk) => {
            body += chunk.toString();
          });
          req.on("end", () => {
            try {
              const data = readData();
              const newItem = {
                id: Date.now().toString(),
                ...JSON.parse(body),
              };
              data.portfolioItems = data.portfolioItems || [];
              data.portfolioItems.push(newItem);
              writeData(data);
              res.writeHead(200, { "Content-Type": "application/json" });
              res.end(JSON.stringify(newItem));
            } catch (error) {
              res.writeHead(500, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ error: "Erro ao salvar portfólio" }));
            }
          });
          return;
        }
        next();
      });

      // DELETE /api/portfolio/:id
      server.middlewares.use("/api/portfolio/", (req, res, next) => {
        if (req.method === "DELETE" && req.url?.startsWith("/api/portfolio/")) {
          const id = req.url.split("/").pop();
          try {
            const data = readData();
            data.portfolioItems = (data.portfolioItems || []).filter(
              (item: any) => item.id !== id
            );
            writeData(data);
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: true }));
          } catch (error) {
            res.writeHead(500, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ error: "Erro ao deletar portfólio" }));
          }
          return;
        }
        next();
      });

      // PUT /api/portfolio/:id
      server.middlewares.use("/api/portfolio/", (req, res, next) => {
        if (req.method === "PUT" && req.url?.startsWith("/api/portfolio/")) {
          const id = req.url.split("/").pop();
          let body = "";
          req.on("data", (chunk) => {
            body += chunk.toString();
          });
          req.on("end", () => {
            try {
              const data = readData();
              const index = (data.portfolioItems || []).findIndex(
                (item: any) => item.id === id
              );
              if (index !== -1) {
                data.portfolioItems[index] = {
                  ...data.portfolioItems[index],
                  ...JSON.parse(body),
                };
                writeData(data);
                res.writeHead(200, { "Content-Type": "application/json" });
                res.end(JSON.stringify(data.portfolioItems[index]));
              } else {
                res.writeHead(404, { "Content-Type": "application/json" });
                res.end(JSON.stringify({ error: "Portfólio não encontrado" }));
              }
            } catch (error) {
              res.writeHead(500, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ error: "Erro ao atualizar portfólio" }));
            }
          });
          return;
        }
        next();
      });

      // GET /api/works
      server.middlewares.use("/api/works", (req, res, next) => {
        if (req.method === "GET") {
          const data = readData();
          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify(data.ongoingWorks || []));
          return;
        }
        next();
      });

      // POST /api/works
      server.middlewares.use("/api/works", (req, res, next) => {
        if (req.method === "POST") {
          let body = "";
          req.on("data", (chunk) => {
            body += chunk.toString();
          });
          req.on("end", () => {
            try {
              const data = readData();
              const newItem = {
                id: Date.now().toString(),
                ...JSON.parse(body),
              };
              data.ongoingWorks = data.ongoingWorks || [];
              data.ongoingWorks.push(newItem);
              writeData(data);
              res.writeHead(200, { "Content-Type": "application/json" });
              res.end(JSON.stringify(newItem));
            } catch (error) {
              res.writeHead(500, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ error: "Erro ao salvar obra" }));
            }
          });
          return;
        }
        next();
      });

      // DELETE /api/works/:id
      server.middlewares.use("/api/works/", (req, res, next) => {
        if (req.method === "DELETE" && req.url?.startsWith("/api/works/")) {
          const id = req.url.split("/").pop();
          try {
            const data = readData();
            data.ongoingWorks = (data.ongoingWorks || []).filter(
              (item: any) => item.id !== id
            );
            writeData(data);
            res.writeHead(200, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: true }));
          } catch (error) {
            res.writeHead(500, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ error: "Erro ao deletar obra" }));
          }
          return;
        }
        next();
      });

      // PUT /api/works/:id
      server.middlewares.use("/api/works/", (req, res, next) => {
        if (req.method === "PUT" && req.url?.startsWith("/api/works/")) {
          const id = req.url.split("/").pop();
          let body = "";
          req.on("data", (chunk) => {
            body += chunk.toString();
          });
          req.on("end", () => {
            try {
              const data = readData();
              const index = (data.ongoingWorks || []).findIndex(
                (item: any) => item.id === id
              );
              if (index !== -1) {
                data.ongoingWorks[index] = {
                  ...data.ongoingWorks[index],
                  ...JSON.parse(body),
                };
                writeData(data);
                res.writeHead(200, { "Content-Type": "application/json" });
                res.end(JSON.stringify(data.ongoingWorks[index]));
              } else {
                res.writeHead(404, { "Content-Type": "application/json" });
                res.end(JSON.stringify({ error: "Obra não encontrada" }));
              }
            } catch (error) {
              res.writeHead(500, { "Content-Type": "application/json" });
              res.end(JSON.stringify({ error: "Erro ao atualizar obra" }));
            }
          });
          return;
        }
        next();
      });
    },
  };
}

function vitePluginManusDebugCollector(): Plugin {
  return {
    name: "manus-debug-collector",

    transformIndexHtml(html) {
      if (process.env.NODE_ENV === "production") {
        return html;
      }
      return {
        html,
        tags: [
          {
            tag: "script",
            attrs: {
              src: "/__manus__/debug-collector.js",
              defer: true,
            },
            injectTo: "head",
          },
        ],
      };
    },

    configureServer(server: ViteDevServer) {
      // POST /__manus__/logs: Browser sends logs (written directly to files)
      server.middlewares.use("/__manus__/logs", (req, res, next) => {
        if (req.method !== "POST") {
          return next();
        }

        const handlePayload = (payload: any) => {
          // Write logs directly to files
          if (payload.consoleLogs?.length > 0) {
            writeToLogFile("browserConsole", payload.consoleLogs);
          }
          if (payload.networkRequests?.length > 0) {
            writeToLogFile("networkRequests", payload.networkRequests);
          }
          if (payload.sessionEvents?.length > 0) {
            writeToLogFile("sessionReplay", payload.sessionEvents);
          }

          res.writeHead(200, { "Content-Type": "application/json" });
          res.end(JSON.stringify({ success: true }));
        };

        const reqBody = (req as { body?: unknown }).body;
        if (reqBody && typeof reqBody === "object") {
          try {
            handlePayload(reqBody);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
          return;
        }

        let body = "";
        req.on("data", (chunk) => {
          body += chunk.toString();
        });

        req.on("end", () => {
          try {
            const payload = JSON.parse(body);
            handlePayload(payload);
          } catch (e) {
            res.writeHead(400, { "Content-Type": "application/json" });
            res.end(JSON.stringify({ success: false, error: String(e) }));
          }
        });
      });
    },
  };
}

const plugins = [react(), tailwindcss(), jsxLocPlugin(), vitePluginManusRuntime(), vitePluginApiServer(), vitePluginManusDebugCollector()];

export default defineConfig({
  plugins,
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets"),
    },
  },
  envDir: path.resolve(import.meta.dirname),
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true,
  },
  server: {
    port: 3000,
    strictPort: false, // Will find next available port if 3000 is busy
    host: true,
    allowedHosts: [
      ".manuspre.computer",
      ".manus.computer",
      ".manus-asia.computer",
      ".manuscomputer.ai",
      ".manusvm.computer",
      "localhost",
      "127.0.0.1",
    ],
    fs: {
      strict: true,
      deny: ["**/.*"],
    },
  },
});
